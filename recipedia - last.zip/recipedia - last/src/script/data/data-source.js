class DataSource {
  static searchRecipe(keyword) {
    return Promise.all([
      fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${keyword}`).then(resp => resp.json()), //search by name
      fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?i=${keyword}`).then(resp => resp.json()), //search by ingredients
      fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${keyword}`).then(resp => resp.json()), //search by category
      fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?a=${keyword}`).then(resp => resp.json()), //by area
    ])
  
      .then(responseJson => {
      
        const concated = [].concat(responseJson[0].meals, responseJson[1].meals, responseJson[2].meals, responseJson[3].meals); //gabungin responseJSON
        console.log('concated :', concated);

        const filtered = concated.filter(el => el !== null);
        console.log('filtered :', filtered);

        const idMealOnly = filtered.map(row => row.idMeal);
        console.log('idMealOnly:', idMealOnly);

        const noDuplicate = [ ...new Set(idMealOnly)];
        console.log('noDuplicate:', noDuplicate);
        
        if (noDuplicate.length>0) {
          console.log('noDuplicate LENGTH:', noDuplicate.length);
          return Promise.all(noDuplicate.map(id =>
            fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${id}`).then(resp => resp.json())
          ))
          .then(resp => {
            console.log('resp:', resp);
            const flatted = resp.map(o => o.meals).flat();
            console.log('flatted:', flatted);
            return Promise.resolve(flatted);
          });
        } else {
          return Promise.reject(`${keyword} is not found`);
        }
      });
  }
}
 
export default DataSource;