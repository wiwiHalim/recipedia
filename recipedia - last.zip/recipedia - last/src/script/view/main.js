import '../component/recipe-random.js';
import '../component/area-list.js';
import '../component/recipe-list.js';
import '../component/category-list';
import '../component/ingredient-list';
import '../component/top-bar.js';
import DataSource from '../data/data-source.js';

const main = () => {
  const searchElement = document.querySelector('top-bar');
  const ingredientListElement = document.querySelector('ingredient-list');
  const categoryListElement = document.querySelector('category-list');
  const areaListElement = document.querySelector('area-list');
  const recipeListElement = document.querySelector('recipe-list');
  const randomItemElement = document.querySelector('recipe-random');
  
  const onButtonSearchClicked = () => {
    getRandomMeal();
    DataSource.searchRecipe(searchElement.value)
    .then(renderResult)
    .catch(fallbackResult);
  };

  const renderResult = results => {
    recipeListElement.recipes = results;
  };

  const fallbackResult = message => {
    recipeListElement.renderError(message);
  };

  searchElement.addEventListener("keypress", event => {
    if (event.key === "Enter") {
      event.preventDefault();
      onButtonSearchClicked();
    }
  });

  const getCategories = () => {
    fetch(`https://www.themealdb.com/api/json/v1/1/categories.php`)
        .then(response => {
          return response.json();
        })
        .then(responseJson => {
          if (responseJson.error) {
            showResponseMessage(responseJson.message);
          } else {
            renderAllCategories(responseJson.categories);
          }
        })
        .catch(error => {
          showResponseMessage(error);
        });
  };

  const renderAllCategories = categoriesss => {
    categoryListElement.categoriesqq = categoriesss;
  };

  const showResponseMessage = (message = 'Check your internet connection') => {
    alert(message);
  };
  
  const getAreas = () => {
    fetch(`https://www.themealdb.com/api/json/v1/1/list.php?a=list`)
        .then(response => {
            return response.json();
        })
        .then(responseJson => {
            if (responseJson.error) {
              showResponseMessage(responseJson.message);
            } else {
              renderAllAreas(responseJson.meals);
            }
         })
        .catch(error => {
             showsResponseMessage(error);
        });
  };

  const renderAllAreas = area => {
    areaListElement.areas = area;
  };

  const getIngredient = () => {
    fetch(`https://www.themealdb.com/api/json/v1/1/list.php?i=list`)
      .then(response => {
        return response.json();
      })
      .then(responseJson => {
        if (responseJson.error) {
          showResponseMessage(responseJson.message);
        } else {
          renderAllIngredient(responseJson.meals);
        }
      })
      .catch(error => {
          showsResponseMessage(error);
      });
  };

  const renderAllIngredient = ingredient => {
    ingredientListElement.ingredients = ingredient;
  };

  const getRandomMeal = () => {
    fetch(`https://www.themealdb.com/api/json/v1/1/random.php`)
      .then(response => {
        return response.json();
      })
      .then(responseJson => {
        if (responseJson.error) {
          showResponseMessage(responseJson.message);
        } else {
          renderRandomMeal(responseJson.meals);
        }
      })
      .catch(error => {
        showResponseMessage(error);
      });
  };
  
  const renderRandomMeal = randoma => {
    randomItemElement.randomen = randoma;
  };

  getAreas();
  getCategories();
  getIngredient();
  getRandomMeal();

  searchElement.clickEvent = onButtonSearchClicked;

  categoryListElement.onclick = e => {
    DataSource.searchRecipe(e.target.innerText)
    .then(renderResult)
    .catch(fallbackResult);
    getRandomMeal();
  }
  areaListElement.onclick = e => {
    DataSource.searchRecipe(e.target.innerText)
    .then(renderResult)
    .catch(fallbackResult);
    getRandomMeal();
  }
  ingredientListElement.onclick = e => {
    DataSource.searchRecipe(e.target.innerText)
    .then(renderResult)
    .catch(fallbackResult);
    getRandomMeal();
  }
};

export default main;
