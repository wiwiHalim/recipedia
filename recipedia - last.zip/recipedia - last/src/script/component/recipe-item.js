class RecipeItem extends HTMLElement {

  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }

    set recipe(recipe) {
        this._recipe = recipe;
        this.render();
    }
   
    render() {
        this.shadowDOM.innerHTML = `
        <style>
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        :host {
          padding: 15px;
          margin-bottom: 18px;
          box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
          border-radius: 10px;
          display: flex;
          background-color: #F9EBC8;
          margin-left: 10px;
          width: 90%;
        }

        .mealThumb {
          max-height: 200px;
          object-fit: cover;
          display: inline-block;
          border-radius: 10px;
        }

        .mealInfo {
          margin-left: 20px;
        }

        details > summary {
          font-weight: bold;
          font-size: 20px;
        }

        details > p, h5 {
          line-height: 1.8;
        }

        details > h5 {
          margin-top : 10px;
          margin-bottom : 10px;
          font-size: 17px;
        }
          
        p{
          line-height: 1.8;
        }

        a{
          text-decoration: none;
        }

        a:hover{
          text-decoration: underline;
        }
        .duakolom{
          display: flex;
          flex-direcion: row;
        }
        .measure{
          width: fit-content;
        }
        .ingre{
          width: fit-content;
          margin-left: 20px ;
        }

        @media screen and (max-width: 400px) {
          :host {
            display: flex;
            flex-direction: column;
            margin: auto;
            margin-bottom: 18px;
          }
          .mealThumb {
            object-fit: contain;
            display: block;
          }
          .mealInfo {
            justify-content: center;
            margin: 5px;
            padding: 0px;
            width: auto;
            display: block;
          }
          p{
            overflow: auto;
          }
          .ingre{
            margin-left: 50px ;
          }
        }
      </style>

      <img class="mealThumb" src="${this._recipe.strMealThumb}" alt="Meal thumb">
      <div class="mealInfo">
        <details>
          <summary>${this._recipe.strMeal}</summary>
          <h5>Ingredients</h5>
          <div class="duakolom">
            <div class="measure">
              <p>${this._recipe.strMeasure1}</p>
              <p>${this._recipe.strMeasure2}</p>
              <p>${this._recipe.strMeasure3}</p>
              <p>${this._recipe.strMeasure4}</p>
              <p>${this._recipe.strMeasure5}</p>
              <p>${this._recipe.strMeasure6}</p>
              <p>${this._recipe.strMeasure7}</p>
              <p>${this._recipe.strMeasure8}</p>
              <p>${this._recipe.strMeasure9}</p>
              <p>${this._recipe.strMeasure10}</p>
              <p>${this._recipe.strMeasure11}</p>
              <p>${this._recipe.strMeasure12}</p>
              <p>${this._recipe.strMeasure13}</p>
              <p>${this._recipe.strMeasure14}</p>
              <p>${this._recipe.strMeasure15}</p>
              <p>${this._recipe.strMeasure16}</p>
              <p>${this._recipe.strMeasure17}</p>
              <p>${this._recipe.strMeasure18}</p>
              <p>${this._recipe.strMeasure19}</p>
              <p>${this._recipe.strMeasure20}</p>

            </div>
            <div class="ingre">
            <p>${this._recipe.strIngredient1}</p>
            <p>${this._recipe.strIngredient2}</p>
            <p>${this._recipe.strIngredient3}</p>
            <p>${this._recipe.strIngredient4}</p>
            <p>${this._recipe.strIngredient5}</p>
            <p>${this._recipe.strIngredient6}</p>
            <p>${this._recipe.strIngredient7}</p>
            <p>${this._recipe.strIngredient8}</p>
            <p>${this._recipe.strIngredient9}</p>
            <p>${this._recipe.strIngredient10}</p>
            <p>${this._recipe.strIngredient11}</p>
            <p>${this._recipe.strIngredient12}</p>
            <p>${this._recipe.strIngredient13}</p>
            <p>${this._recipe.strIngredient14}</p>
            <p>${this._recipe.strIngredient15}</p>
            <p>${this._recipe.strIngredient16}</p>
            <p>${this._recipe.strIngredient17}</p>
            <p>${this._recipe.strIngredient18}</p>
            <p>${this._recipe.strIngredient19}</p>
            <p>${this._recipe.strIngredient20}</p>
            </div>
          </div>
          <h5>How to Cook</h5>
          <p>${this._recipe.strInstructions}</p>
        </details>
        <p>---</p>
        <p>Category : ${this._recipe.strCategory}</p>
        <p>Area : ${this._recipe.strArea}</p>
        <p>Tags : ${this._recipe.strTags}</p>
        <p><a href="${this._recipe.strSource}">Source</a> & <a href="${this._recipe.strYoutube}">Video</a></p>
        <p>---</p>
      </div>
      `;
    }
  }

customElements.define('recipe-item', RecipeItem);