import './ingredient-item';

class IngredientList extends HTMLElement {

    set ingredients(ingredients) {
      this._ingredients = ingredients;
      this.render();
    }

    renderError(message) {
      this.innerHTML = `
      <style>
      .placeholder {
        font-weight: lighter;
        color: rgba(0, 0, 0, 0.5);
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }
      </style>
      `;
      this.innerHTML += `<h2 class="placeholder">${message}</h2>`;
    }

    render() {
      this.innerHTML = `
      <style>
        h4{
          padding: 8px;
          background-color: #A0BCC2;
          border-radius: 10px;
        }
      </style>
        <h4>Ingredient</h4>
      `;
      
      this._ingredients.forEach(ingredient => {
        const ingredientItemElement = document.createElement('ingredient-item');
        ingredientItemElement.ingredient = ingredient;
        this.appendChild(ingredientItemElement);
      });
  }
}
    
customElements.define('ingredient-list', IngredientList);