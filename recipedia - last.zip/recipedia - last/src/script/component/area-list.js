import './area-item';

class AreaList extends HTMLElement {

    set areas(areas) {
      this._areas = areas;
      this.render();
    }

    renderError(message) {
      this.innerHTML = `
      <style>
      .placeholder {
        font-weight: lighter;
        color: rgba(0, 0, 0, 0.5);
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }
      </style>
      `;
      this.innerHTML += `<h2 class="placeholder">${message}</h2>`;
    }

    render() {
      this.innerHTML = `
      <style>
        h4{
          padding: 8px;
          background-color: #A0BCC2;
          border-radius: 10px;
        }
      </style>
        <h4>Area</h4>
      `;
      
      this._areas.forEach(area => {
        const areaItemElement = document.createElement('area-item');
        areaItemElement.area = area;
        this.appendChild(areaItemElement);
      });
  }
}
    
customElements.define('area-list', AreaList);