class TopBar extends HTMLElement {

  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }

  connectedCallback() {
    this.render();
  }

  set clickEvent(event) {
    this._clickEvent = event;
    this.render();
  }
    
  get value() {
    return this.shadowDOM.querySelector('#searchElement').value;
  }
    
  render() {
    this.shadowDOM.innerHTML = `
      <style>

        * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        }

        :host {
          width: 100%;
          display: flex;
          position: sticky;
          background-color: #A0BCC2;
        }

        .web-name {
          padding: 15px;
          display: inline-block;
          text-align: center;
          width: 15%; 
          color: #F9EBC8;
        }

        .search-container {
          display: flex;
          padding: 2px;
          border-radius: 10px;
          width: 500px;
          border: 2px solid #DAE5D0;
          margin: 10px;
        }
        
        .search-container > input {
          width: 95%;
          padding: 7px 8px;
          font-size: 14px;
          font-weight: bold;
          border: 1px solid transparent;
          border-radius: inherit;
          background-color: inherit;
          color : #EAE3D2;
        }
        
        .search-container > input:focus {
          outline: 0;
          border: 2px solid #DAE5D0;
        } 

        .search-container > input::placeholder {
          color: #EAE3D2;
          font-weight: bold;
        }

        .search-container > input:focus::placeholder {
          font-weight: bold;
          color: #A0BCC2;
        }
        
        .search-container > button {
          width: 40px;
          padding: 0;
          margin: 0;
          border: 1px solid transparent;
          border-radius: inherit;
          background: transparent url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' class='bi bi-search' viewBox='0 0 16 16'%3E%3Cpath d='M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z'%3E%3C/path%3E%3C/svg%3E") no-repeat center;
          cursor: pointer;
          opacity: 0.7;
        }
        
        @media screen and (max-width: 1000px) {
          :host {
            display: flex;
            flex-direction: row;
            position: sticky;
          }
          .web-name {
            width: auto;
          }
          .search-container {
            width: 50%;
          }
        }
        @media screen and (max-width: 400px) {
          :host {
            display: flex;
            flex-direction: column;
            position: sticky;
          }
          .web-name {
            width: 100%;
          }
          .search-container {
            width: 100%;
            margin: 0px;
          }
        }
        </style>

        <div class="web-name">
          <h1>Recipedia</h1>
        </div>

        <div class="search-container">
          <input type="search" placeholder="Search recipes by name or ingredient" id="searchElement">
          <button type="submit" id="searchButtonElement"></button>
        </div>
      `;

  this.shadowDOM.querySelector('#searchButtonElement').addEventListener('click', this._clickEvent);


  }
}

customElements.define('top-bar', TopBar);