class IngredientItem extends HTMLElement {

    set ingredient(ingredient) {
        this._ingredient = ingredient;
        this.render();
    }

    render() {
        this.innerHTML = `
        <style>
        
        * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      ingredient-item > button {
        padding: 8px;
        border: 1px solid transparent;
        border-radius: 10px;
        font-size: 16px;
        background-color: #DAE5D0;
        display: block;
        width: 100%;
        text-align: left;
      }

      ingredient-item > button:hover {
        background-color: #FEFBE7;
      }
      
      </style>
      <button type="submit" id="ingredient" value="${this._ingredient.strIngredient}">${this._ingredient.strIngredient}</button>
      `;

    //this.querySelector('#area').addEventListener('click', this._clickEvent);
  }
}

customElements.define('ingredient-item', IngredientItem);