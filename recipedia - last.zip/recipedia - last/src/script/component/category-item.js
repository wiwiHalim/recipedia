class CategoryItem extends HTMLElement {

    set category(category) {
        this._category = category;
        this.render();
    }

    render() {
        this.innerHTML = `
        <style>

        * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      category-item > button {
        padding: 8px;
        border: 1px solid transparent;
        border-radius: 10px;
        font-size: 16px;
        background-color: #DAE5D0;
        display: block;
        width: 100%;
        text-align: left;
      }

      category-item > button:hover {
        background-color: #F9EBC8;
      }

      </style>
      <button type="submit" id="kategori" value="${this._category.strCategory}">${this._category.strCategory}</button>
      `;

    this.querySelector('#kategori').addEventListener('click', this._clickEvent);
  }
}

customElements.define('category-item', CategoryItem);