import './category-item.js';

class CategoryList extends HTMLElement {

    set categoriesqq(kategorii) {
      this._categoriesqq = kategorii;
      this.render();
    }
  
    //fungsi untuk menangani ketika hasil pencarian mengalami kegagalan atau tidak ditemukkan
    renderError(message) {
      this.innerHTML = `
      <style>
      .placeholder {
        font-weight: lighter;
        color: rgba(0, 0, 0, 0.5);
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }
      </style>
      `;
      this.innerHTML += `<h2 class="placeholder">${message}</h2>`;
    }

    render() {
      this.innerHTML = `
      <style>
      h4{
        padding: 8px;
        background-color: #A0BCC2;
        border-radius: 10px;
      }
      </style>
        <h4>Category</h4>
      `;
      
      this._categoriesqq.forEach(category => {
        const categoryItemElement = document.createElement('category-item');
        categoryItemElement.category = category;
        this.appendChild(categoryItemElement);
      });
  }
}
    
customElements.define('category-list', CategoryList);