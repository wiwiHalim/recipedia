import './recipe-item';

class RecipeRandom extends HTMLElement {
  constructor() {
    super();
    this.shadowDOM = this.attachShadow({mode: 'open'});
  }

    set randomen(randomi) {
        this._randomen = randomi;
        this.render();
    }
   
    renderError(message) {
        this.shadowDOM.innerHTML = `
        <style>
        .placeholder {
          font-weight: lighter;
          color: rgba(0, 0, 0, 0.5);
          -webkit-user-select: none;
          -moz-user-select: none;
          -ms-user-select: none;
          user-select: none;
        }
        </style>
        `;
        this.shadowDOM.innerHTML += `<h2 class="placeholder">${message}</h2>`;
    }

    render() {
        this.shadowDOM.innerHTML = `
        <style>
        h4{
          margin-left: 10px;
        }
      </style>
        <h4>Here is a random meal idea for you! ^^</h4>`;
        this._randomen.forEach(recipe => {
          const randomItemElement = document.createElement('recipe-item');
          randomItemElement.recipe = recipe;
          this.shadowDOM.appendChild(randomItemElement);
        });
    }
  }

customElements.define('recipe-random', RecipeRandom);