class AreaItem extends HTMLElement {

    set area(area) {
        this._area = area;
        this.render();
    }

    render() {
      this.innerHTML = `
      <style>

      * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
      }

      area-item > button {
        padding: 8px;
        border: 1px solid transparent;
        border-radius: 10px;
        font-size: 16px;
        background-color: #DAE5D0;
        display: block;
        width: 100%;
        text-align: left;
      }

      area-item > button:hover {
        background-color: #FEFBE7;
      }

      </style>
      <button type="submit" id="area" value="${this._area.strArea}">${this._area.strArea}</button>
      `;
  }
}

customElements.define('area-item', AreaItem);